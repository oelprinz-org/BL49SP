# LambdaCtrl
License <br />
[![License: CC BY-NC 4.0](https://img.shields.io/badge/License-CC%20BY--NC%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc/4.0/)
<br />

Wideband lambda controller based on bosch cj125.
Only LSU 4.9 is supported at the moment.

This project is a firmware implememtation for the NanoLambda Board from ruzki.
https://github.com/ruzki/Nano_Lambda




